//
//  SendNamePhoneNumberDelegate.swift
//  final_test3
//
//  Created by 姜禹廷 on 2023/12/7.
//

import Foundation

protocol SendNamePhoneNumberDelegate{
    func sendNamePhoneNumber(name: String, lastName: String, phoneNumber: String)
}
