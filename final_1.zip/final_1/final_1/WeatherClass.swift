//
//  WeatherClass.swift
//  final_1
//
//  Created by 姜禹廷 on 2023/12/9.
//

import Foundation

class WeatherClass {
    var city: String = ""
    var temperature: Int = 0
    var conditions: String = ""
}
