//
//  Constants.swift
//  final_1
//
//  Created by 姜禹廷 on 2023/12/9.
//

import Foundation

let baseURL = "https://us-central1-fir-api-s-8d31b.cloudfunctions.net/app"

